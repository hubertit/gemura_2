<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../../shared/order-utils.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

try {
    // Get query parameters
    $sellerId = isset($_GET['seller_id']) ? (int)$_GET['seller_id'] : null;
    $status = isset($_GET['status']) ? $_GET['status'] : null;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $offset = ($page - 1) * $limit;

    // Seller ID is required for security
    if (!$sellerId) {
        http_response_code(400);
        echo json_encode(['error' => 'Seller ID is required']);
        exit;
    }

    // Build base query - only seller's orders to fulfill
    $sql = "SELECT 
                o.*,
                c.name as customer_name,
                c.phone as customer_phone,
                c.email as customer_email,
                COUNT(oi.id) as total_items,
                SUM(oi.total_price) as calculated_total
            FROM orders o
            LEFT JOIN users c ON o.customer_id = c.id
            LEFT JOIN order_items oi ON o.id = oi.order_id
            WHERE o.seller_id = $sellerId";

    $whereConditions = [];

    if ($status) {
        $whereConditions[] = "o.status = '$status'";
    }

    if (!empty($whereConditions)) {
        $sql .= " AND " . implode(' AND ', $whereConditions);
    }

    $sql .= " GROUP BY o.id ORDER BY o.order_date DESC";

    // Get total count for pagination
    $countSql = "SELECT COUNT(DISTINCT o.id) as total FROM orders o WHERE o.seller_id = $sellerId";
    if (!empty($whereConditions)) {
        $countSql .= " AND " . implode(' AND ', $whereConditions);
    }
    
    $countResult = mysqli_query($connection, $countSql);
    $totalOrders = mysqli_fetch_assoc($countResult)['total'];

    // Add pagination
    $sql .= " LIMIT $limit OFFSET $offset";

    $result = mysqli_query($connection, $sql);

    if (!$result) {
        throw new Exception("Database error: " . mysqli_error($connection));
    }

    $orders = [];
    while ($row = mysqli_fetch_assoc($result)) {
        // Get order items using shared function
        $items = getOrderItems($connection, $row['id']);

        $orders[] = [
            'id' => (int)$row['id'],
            'order_no' => $row['order_no'],
            'customer_id' => (int)$row['customer_id'],
            'customer_name' => $row['customer_name'],
            'customer_phone' => $row['customer_phone'],
            'customer_email' => $row['customer_email'],
            'total_amount' => (float)$row['total_amount'],
            'currency' => $row['currency'],
            'status' => $row['status'],
            'shipping_address' => $row['shipping_address'],
            'shipping_notes' => $row['shipping_notes'],
            'order_date' => $row['order_date'],
            'updated_at' => $row['updated_at'],
            'cancellation_reason' => $row['cancellation_reason'],
            'total_items' => (int)$row['total_items'],
            'calculated_total' => (float)$row['calculated_total'],
            'items' => $items
        ];
    }

    $totalPages = ceil($totalOrders / $limit);
    $hasNext = $page < $totalPages;
    $hasPrev = $page > 1;

    echo json_encode([
        'success' => true,
        'data' => [
            'orders' => $orders,
            'pagination' => [
                'current_page' => $page,
                'total_pages' => $totalPages,
                'total_orders' => $totalOrders,
                'limit' => $limit,
                'has_next' => $hasNext,
                'has_prev' => $hasPrev
            ]
        ]
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}

mysqli_close($connection);
?>
